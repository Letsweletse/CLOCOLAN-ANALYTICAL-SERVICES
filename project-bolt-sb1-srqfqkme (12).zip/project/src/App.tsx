import React from 'react';
import { motion } from 'framer-motion';
import { Phone, Mail, MapPin, Clock, ArrowRight, ChevronRight, Microscope, Factory, PenTool as Tool, Scale, Wind, Shield } from 'lucide-react';
import { Toaster } from 'react-hot-toast';
import { HelmetProvider, Helmet } from 'react-helmet-async';
import { ImageSlider } from './components/ImageSlider';
import { ClientSlider } from './components/ClientSlider';
import { TestimonialSlider } from './components/TestimonialSlider';
import { Portfolio } from './components/Portfolio';
import 'swiper/css';
import 'swiper/css/navigation';
import 'swiper/css/pagination';

function App() {
  const openWhatsApp = () => {
    window.open('https://wa.me/2675880709', '_blank');
  };

  return (
    <HelmetProvider>
      <div className="min-h-screen bg-white">
        <Helmet>
          <title>Clocolan Analytical Services - Air Quality Monitoring & Industrial Solutions</title>
          <meta name="description" content="Specialists in gas detection, air quality monitoring, and industrial instrumentation services across Southern Africa." />
        </Helmet>
        
        {/* Top Contact Bar */}
        <div className="bg-blue-900 text-white py-2 px-4">
          <div className="container mx-auto flex justify-between items-center text-sm">
            <div className="flex items-center gap-4">
              <a href="tel:+2675880709" className="flex items-center gap-1">
                <Phone size={14} /> +267 5880709
              </a>
              <a href="mailto:sales@clocolananalyticalservices.com" className="flex items-center gap-1">
                <Mail size={14} /> sales@clocolananalyticalservices.com
              </a>
            </div>
            <div className="flex items-center gap-2">
              <Clock size={14} />
              <span>Mon - Fri: 8:00 - 17:00</span>
            </div>
          </div>
        </div>

        {/* Header */}
        <header className="sticky top-0 bg-white shadow-md z-50">
          <nav className="container mx-auto px-6 py-4">
            <div className="flex justify-between items-center">
              <motion.div 
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                className="h-12"
              >
                <img 
                  src="https://raw.githubusercontent.com/yourusername/bolt-workspace/main/clocolan-logo.png" 
                  alt="Clocolan Analytical Services"
                  className="h-full w-auto"
                />
              </motion.div>
              <div className="hidden md:flex gap-8">
                <a href="#services" className="text-gray-700 hover:text-blue-900">Services</a>
                <a href="#portfolio" className="text-gray-700 hover:text-blue-900">Portfolio</a>
                <a href="#about" className="text-gray-700 hover:text-blue-900">About</a>
                <a href="#contact" className="text-gray-700 hover:text-blue-900">Contact</a>
              </div>
              <button
                onClick={openWhatsApp}
                className="bg-green-500 text-white px-4 py-2 rounded-full hover:bg-green-600 transition-colors flex items-center gap-2"
              >
                WhatsApp Us
              </button>
            </div>
          </nav>
        </header>

        {/* Hero Section with Image Slider */}
        <section className="relative">
          <ImageSlider />
        </section>

        {/* Services Section */}
        <section id="services" className="py-20 bg-gray-50">
          <div className="container mx-auto px-6">
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              className="text-center mb-16"
            >
              <h3 className="text-3xl font-bold text-blue-900 mb-4">Our Services</h3>
              <p className="text-gray-600 max-w-2xl mx-auto">
                Comprehensive solutions for industrial air quality monitoring, instrumentation, and maintenance.
              </p>
            </motion.div>

            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
              {[
                {
                  icon: <Microscope className="w-12 h-12 text-blue-900" />,
                  title: "Gas Detection Systems",
                  description: "Supply, installation, and maintenance of advanced gas detection systems for industrial applications."
                },
                {
                  icon: <Factory className="w-12 h-12 text-blue-900" />,
                  title: "Air Quality Monitoring",
                  description: "Comprehensive air quality monitoring services for processing industries and manufacturing plants."
                },
                {
                  icon: <Tool className="w-12 h-12 text-blue-900" />,
                  title: "Industrial Instrumentation",
                  description: "Installation and maintenance of pressure, level, temperature, and vibration monitoring instruments."
                },
                {
                  icon: <Scale className="w-12 h-12 text-blue-900" />,
                  title: "Weighing Systems",
                  description: "LOADTECH weighing systems for heavy-duty earthmoving and material handling applications."
                },
                {
                  icon: <Wind className="w-12 h-12 text-blue-900" />,
                  title: "Dust Monitoring",
                  description: "Portable steel dust meters for early detection in bearing/gearbox oil and grease."
                },
                {
                  icon: <Shield className="w-12 h-12 text-blue-900" />,
                  title: "Maintenance Services",
                  description: "Expert maintenance, calibration, and technical support for all our solutions."
                }
              ].map((service, index) => (
                <motion.div
                  key={index}
                  initial={{ opacity: 0, y: 20 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  viewport={{ once: true }}
                  transition={{ delay: index * 0.1 }}
                  className="bg-white p-6 rounded-lg shadow-lg"
                >
                  <div className="mb-4">{service.icon}</div>
                  <h4 className="text-xl font-bold text-blue-900 mb-2">{service.title}</h4>
                  <p className="text-gray-600">{service.description}</p>
                </motion.div>
              ))}
            </div>
          </div>
        </section>

        {/* Portfolio Section */}
        <Portfolio />

        {/* About Section */}
        <section id="about" className="py-20">
          <div className="container mx-auto px-6">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-12 items-center">
              <motion.div
                initial={{ opacity: 0, x: -20 }}
                whileInView={{ opacity: 1, x: 0 }}
                viewport={{ once: true }}
              >
                <img 
                  src="https://images.unsplash.com/photo-1581092921461-39b21c514a3a?auto=format&fit=crop&w=800"
                  alt="Industrial facility"
                  className="rounded-lg shadow-lg"
                />
              </motion.div>
              <motion.div
                initial={{ opacity: 0, x: 20 }}
                whileInView={{ opacity: 1, x: 0 }}
                viewport={{ once: true }}
              >
                <h3 className="text-3xl font-bold text-blue-900 mb-6">About Clocolan Analytical Services</h3>
                <p className="text-gray-600 mb-4">
                  Founded in 2010, Clocolan Analytical Services has established itself as a leader in air quality monitoring and industrial instrumentation services across Southern Africa.
                </p>
                <p className="text-gray-600 mb-4">
                  As the sole agent for New Cosmos-BIE in Southern Africa, we provide cutting-edge gas detection solutions for various industries including photovoltaic, semiconductor, and chemical sectors.
                </p>
                <p className="text-gray-600 mb-6">
                  Since March 2023, we are proud to be a 100% Botswana citizen-owned company, serving clients across Botswana, South Africa, Mozambique, and Zimbabwe.
                </p>
                <ul className="space-y-3">
                  {[
                    "Certified technical expertise",
                    "International partnerships",
                    "Regional coverage",
                    "Competitive pricing"
                  ].map((point, index) => (
                    <li key={index} className="flex items-center gap-2 text-gray-700">
                      <ChevronRight className="text-blue-900" size={20} />
                      {point}
                    </li>
                  ))}
                </ul>
              </motion.div>
            </div>
          </div>
        </section>

        {/* Client Slider Section */}
        <ClientSlider />

        {/* Testimonials Section */}
        <TestimonialSlider />

        {/* Contact Section */}
        <section id="contact" className="py-20 bg-gray-50">
          <div className="container mx-auto px-6">
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              className="max-w-4xl mx-auto"
            >
              <div className="text-center mb-12">
                <h3 className="text-3xl font-bold text-blue-900 mb-4">Contact Us</h3>
                <p className="text-gray-600">
                  Get in touch with our team for expert consultation and support.
                </p>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                <div className="bg-white p-6 rounded-lg shadow-lg">
                  <h4 className="text-xl font-bold text-blue-900 mb-4">Contact Information</h4>
                  <div className="space-y-4">
                    <div className="flex items-start gap-3">
                      <MapPin className="text-blue-900 mt-1" />
                      <div>
                        <p className="font-medium">Address:</p>
                        <p className="text-gray-600">Upper Floor Plot 829, Office No 3, Main Mall, Jwaneng, Botswana</p>
                      </div>
                    </div>
                    <div className="flex items-center gap-3">
                      <Phone className="text-blue-900" />
                      <div>
                        <p className="font-medium">Phone:</p>
                        <a href="tel:+2675880709" className="text-gray-600">+267 5880709</a>
                      </div>
                    </div>
                    <div className="flex items-center gap-3">
                      <Mail className="text-blue-900" />
                      <div>
                        <p className="font-medium">Email:</p>
                        <a href="mailto:sales@clocolananalyticalservices.com" className="text-gray-600">
                          sales@clocolananalyticalservices.com
                        </a>
                      </div>
                    </div>
                  </div>
                </div>

                <div className="bg-white p-6 rounded-lg shadow-lg">
                  <h4 className="text-xl font-bold text-blue-900 mb-4">Quick Contact</h4>
                  <form className="space-y-4">
                    <div>
                      <label htmlFor="name" className="block text-sm font-medium text-gray-700 mb-1">Name</label>
                      <input
                        type="text"
                        id="name"
                        className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
                      />
                    </div>
                    <div>
                      <label htmlFor="email" className="block text-sm font-medium text-gray-700 mb-1">Email</label>
                      <input
                        type="email"
                        id="email"
                        className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
                      />
                    </div>
                    <div>
                      <label htmlFor="message" className="block text-sm font-medium text-gray-700 mb-1">Message</label>
                      <textarea
                        id="message"
                        rows={4}
                        className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
                      ></textarea>
                    </div>
                    <button
                      type="submit"
                      className="w-full bg-blue-900 text-white py-2 px-4 rounded-md hover:bg-blue-800 transition-colors"
                    >
                      Send Message
                    </button>
                  </form>
                </div>
              </div>
            </motion.div>
          </div>
        </section>

        {/* Footer */}
        <footer className="bg-blue-900 text-white py-12">
          <div className="container mx-auto px-6">
            <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
              <div>
                <div className="h-12 mb-4">
                  <img 
                    src="https://raw.githubusercontent.com/yourusername/bolt-workspace/main/clocolan-logo.png" 
                    alt="Clocolan Analytical Services"
                    className="h-full w-auto brightness-0 invert"
                  />
                </div>
                <p className="text-blue-100 mb-4">
                  A subsidiary of Metswako Chemicals
                </p>
                <p className="text-blue-100">
                  Reg No: BW00003953813
                </p>
              </div>
              <div>
                <h4 className="text-xl font-bold mb-4">Quick Links</h4>
                <ul className="space-y-2">
                  <li><a href="#services" className="text-blue-100 hover:text-white">Services</a></li>
                  <li><a href="#portfolio" className="text-blue-100 hover:text-white">Portfolio</a></li>
                  <li><a href="#about" className="text-blue-100 hover:text-white">About Us</a></li>
                  <li><a href="#contact" className="text-blue-100 hover:text-white">Contact</a></li>
                </ul>
              </div>
              <div>
                <h4 className="text-xl font-bold mb-4">Business Hours</h4>
                <p className="text-blue-100">Monday - Friday</p>
                <p className="text-blue-100">8:00 AM - 5:00 PM</p>
                <button
                  onClick={openWhatsApp}
                  className="mt-4 bg-green-500 text-white px-4 py-2 rounded-full hover:bg-green-600 transition-colors flex items-center gap-2"
                >
                  Chat on WhatsApp
                </button>
              </div>
            </div>
            <div className="border-t border-blue-800 mt-8 pt-8 text-center">
              <p className="text-blue-100">© 2024 Clocolan Analytical Services (Pty) Ltd. All rights reserved.</p>
            </div>
          </div>
        </footer>

        <Toaster position="bottom-right" />
      </div>
    </HelmetProvider>
  );
}

export default App;