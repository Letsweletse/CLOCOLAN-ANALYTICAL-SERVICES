import React from 'react';
import { Swiper, SwiperSlide } from 'swiper/react';
import { Autoplay, Navigation, Pagination } from 'swiper/modules';
import 'swiper/css';
import 'swiper/css/navigation';
import 'swiper/css/pagination';

const images = [
  {
    url: 'https://images.unsplash.com/photo-1581093458791-9f3c3250a8e7?auto=format&fit=crop&w=1200',
    title: 'Air Quality Monitoring',
    description: 'State-of-the-art monitoring solutions'
  },
  {
    url: 'https://images.unsplash.com/photo-1590959651373-a3db0f38a961?auto=format&fit=crop&w=1200',
    title: 'Industrial Solutions',
    description: 'Advanced industrial equipment and systems'
  },
  {
    url: 'https://images.unsplash.com/photo-1581092921461-39b21c514a3a?auto=format&fit=crop&w=1200',
    title: 'Gas Detection',
    description: 'Cutting-edge gas detection technology'
  },
  {
    url: 'https://images.unsplash.com/photo-1581092436491-363fb93ae189?auto=format&fit=crop&w=1200',
    title: 'Quality Assurance',
    description: 'Ensuring safety and compliance'
  }
];

export function ImageSlider() {
  return (
    <Swiper
      modules={[Autoplay, Navigation, Pagination]}
      spaceBetween={0}
      slidesPerView={1}
      navigation
      pagination={{ clickable: true }}
      autoplay={{ delay: 5000 }}
      className="w-full h-[500px]"
    >
      {images.map((image, index) => (
        <SwiperSlide key={index}>
          <div className="relative w-full h-full">
            <img
              src={image.url}
              alt={image.title}
              className="w-full h-full object-cover"
            />
            <div className="absolute inset-0 bg-black bg-opacity-40 flex flex-col items-center justify-center text-white">
              <h3 className="text-4xl font-bold mb-4">{image.title}</h3>
              <p className="text-xl">{image.description}</p>
            </div>
          </div>
        </SwiperSlide>
      ))}
    </Swiper>
  );
}