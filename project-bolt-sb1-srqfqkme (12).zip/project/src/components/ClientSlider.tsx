import React from 'react';
import { Swiper, SwiperSlide } from 'swiper/react';
import { Autoplay } from 'swiper/modules';
import 'swiper/css';

const clients = [
  {
    logo: 'https://images.unsplash.com/photo-1599305445671-ac291c95aaa9?auto=format&fit=crop&w=200',
    name: 'Mining Corp'
  },
  {
    logo: 'https://images.unsplash.com/photo-1599305445671-ac291c95aaa9?auto=format&fit=crop&w=200',
    name: 'Industrial Solutions'
  },
  {
    logo: 'https://images.unsplash.com/photo-1599305445671-ac291c95aaa9?auto=format&fit=crop&w=200',
    name: 'Chemical Processing'
  },
  {
    logo: 'https://images.unsplash.com/photo-1599305445671-ac291c95aaa9?auto=format&fit=crop&w=200',
    name: 'Manufacturing Inc'
  }
];

export function ClientSlider() {
  return (
    <div className="bg-gray-100 py-16">
      <div className="container mx-auto px-6">
        <h3 className="text-3xl font-bold text-blue-900 text-center mb-12">Our Trusted Clients</h3>
        <Swiper
          modules={[Autoplay]}
          spaceBetween={30}
          slidesPerView={4}
          autoplay={{ delay: 3000 }}
          loop={true}
          breakpoints={{
            320: { slidesPerView: 1 },
            640: { slidesPerView: 2 },
            768: { slidesPerView: 3 },
            1024: { slidesPerView: 4 }
          }}
        >
          {clients.map((client, index) => (
            <SwiperSlide key={index}>
              <div className="bg-white p-6 rounded-lg shadow-md text-center">
                <img
                  src={client.logo}
                  alt={client.name}
                  className="w-24 h-24 mx-auto mb-4 rounded-full object-cover"
                />
                <h4 className="text-lg font-semibold text-blue-900">{client.name}</h4>
              </div>
            </SwiperSlide>
          ))}
        </Swiper>
      </div>
    </div>
  );
}