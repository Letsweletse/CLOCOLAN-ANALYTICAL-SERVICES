import React from 'react';
import { motion } from 'framer-motion';

const projects = [
  {
    title: 'Mining Safety Implementation',
    description: 'Complete gas detection system installation for a major mining operation',
    image: 'https://images.unsplash.com/photo-1581092921461-39b21c514a3a?auto=format&fit=crop&w=600'
  },
  {
    title: 'Industrial Air Quality Monitoring',
    description: 'Comprehensive air quality monitoring solution for manufacturing plant',
    image: 'https://images.unsplash.com/photo-1581093458791-9f3c3250a8e7?auto=format&fit=crop&w=600'
  },
  {
    title: 'Chemical Plant Safety Systems',
    description: 'Installation of advanced safety monitoring systems',
    image: 'https://images.unsplash.com/photo-1590959651373-a3db0f38a961?auto=format&fit=crop&w=600'
  }
];

export function Portfolio() {
  return (
    <section className="py-20 bg-gray-50">
      <div className="container mx-auto px-6">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="text-center mb-16"
        >
          <h3 className="text-3xl font-bold text-blue-900 mb-4">Project Portfolio</h3>
          <p className="text-gray-600 max-w-2xl mx-auto">
            Explore our successful implementations and solutions across various industries.
          </p>
        </motion.div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {projects.map((project, index) => (
            <motion.div
              key={index}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: index * 0.1 }}
              className="bg-white rounded-lg overflow-hidden shadow-lg"
            >
              <img
                src={project.image}
                alt={project.title}
                className="w-full h-48 object-cover"
              />
              <div className="p-6">
                <h4 className="text-xl font-bold text-blue-900 mb-2">{project.title}</h4>
                <p className="text-gray-600">{project.description}</p>
              </div>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}