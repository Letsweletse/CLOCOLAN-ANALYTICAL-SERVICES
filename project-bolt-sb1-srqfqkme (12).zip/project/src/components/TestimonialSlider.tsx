import React from 'react';
import { Swiper, SwiperSlide } from 'swiper/react';
import { Autoplay, Pagination } from 'swiper/modules';
import { Quote } from 'lucide-react';
import 'swiper/css';
import 'swiper/css/pagination';

const testimonials = [
  {
    name: 'John Smith',
    position: 'Operations Manager',
    company: 'Mining Corp',
    testimonial: 'Clocolan Analytical Services has been instrumental in maintaining our air quality standards. Their expertise and professional service are unmatched.'
  },
  {
    name: 'Sarah Johnson',
    position: 'Safety Director',
    company: 'Industrial Solutions',
    testimonial: 'The team at Clocolan provides exceptional support and maintains our gas detection systems with the highest level of professionalism.'
  },
  {
    name: 'Michael Brown',
    position: 'Plant Manager',
    company: 'Chemical Processing',
    testimonial: 'Their quick response time and technical expertise have helped us maintain optimal safety standards in our facility.'
  }
];

export function TestimonialSlider() {
  return (
    <div className="bg-white py-16">
      <div className="container mx-auto px-6">
        <h3 className="text-3xl font-bold text-blue-900 text-center mb-12">Client Testimonials</h3>
        <Swiper
          modules={[Autoplay, Pagination]}
          spaceBetween={30}
          slidesPerView={1}
          pagination={{ clickable: true }}
          autoplay={{ delay: 5000 }}
        >
          {testimonials.map((testimonial, index) => (
            <SwiperSlide key={index}>
              <div className="max-w-3xl mx-auto text-center">
                <Quote className="w-12 h-12 text-blue-900 mx-auto mb-6" />
                <p className="text-xl text-gray-600 mb-6">"{testimonial.testimonial}"</p>
                <div>
                  <p className="font-bold text-blue-900">{testimonial.name}</p>
                  <p className="text-gray-600">{testimonial.position}</p>
                  <p className="text-gray-600">{testimonial.company}</p>
                </div>
              </div>
            </SwiperSlide>
          ))}
        </Swiper>
      </div>
    </div>
  );
}